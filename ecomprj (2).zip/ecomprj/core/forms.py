from django import forms
from core.models import Category

class ProductForm(forms.Form):
    pname = forms.CharField( max_length=100, required=True, label="Name")
    cource = forms.ModelChoiceField(queryset=Category.objects.all(), empty_label="Select ", required=True, label="Cource")
    newp = forms.DecimalField(decimal_places=2, max_digits=5, required=True, label="New Price")
    oldp = forms.DecimalField(decimal_places=2, max_digits=5, required=True, label="Old price")
    year = forms.CharField(max_length = 50,required=True, label="Semester/Year")
    description = forms.CharField( max_length=1000, required=True, label="Description")
    image = forms.ImageField( required=True, label="Upload Image")

    
