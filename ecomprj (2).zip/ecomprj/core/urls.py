from django.urls import path
from core.views import index, contact, about_us, purchase_guide, privacy_policy, terms_of_service,sell,product_info,cart,account
from ecomprj import settings 
from django.conf.urls.static import static

app_name = "core"

urlpatterns = [
    # Homepage
    path("", index, name="index"),
    path("contact/", contact, name="contact"),
    path("product_info/<int:pk>", product_info, name="product_info"),
    path("about_us/", about_us, name="about_us"),
    path("cart/", cart, name="cart"),
    path("purchase_guide/", purchase_guide, name="purchase_guide"),
    path("privacy_policy/", privacy_policy, name="privacy_policy"),
    path("terms_of_service/", terms_of_service, name="terms_of_service"),
    path("sell/", sell, name="sell"),
    path("account/", account, name = "account"),
]   + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)