#pylint: disable=no-member
from django.shortcuts import render
from .models import Product
from core.forms import ProductForm
from core.models import Product
from django.contrib.auth.models import User
from django.contrib import messages


def index(request):
    products = Product.objects.all()
    return render(request, "core/index.html", {'products' : products})


def product_info (request,pk):
    product = Product.objects.get(id=pk)
    product.discount = product.calculate_discount()  # Calculate discount for the product
    return render(request, "core/product.html", {'product': product})



def sell(request):

    fn = ProductForm()
    data = {"form": fn}

    if request.method == "POST":
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            product_name = form.cleaned_data["pname"]
            cource = form.cleaned_data["cource"]
            year = form.cleaned_data["year"]
            old_price = form.cleaned_data["oldp"]
            new_price = form.cleaned_data["newp"]
            description = form.cleaned_data["description"]
            image = form.cleaned_data["image"]
            

        item = Product(
            product_name = product_name,
            cource = cource,
            year = year,
            old_price = old_price,
            new_price = new_price,
            description = description,
            image = image,
            )
        messages.success(request, "Your item has been uploaded!!")
        item.save()

    else :
        messages.info(request, "ERROR! please try again")
        form = ProductForm()

    return render(request, "core/sell.html", data)


def account(request) :
    return render(request, "core/account.html")

def contact(request):
    return render(request, "core/contact.html")

def about_us(request):
    return render(request, "core/about_us.html")


def cart(request):
    return render (request, "core/cart.html")

def purchase_guide(request):
    return render(request, "core/purchase_guide.html")

def privacy_policy(request):
    return render(request, "core/privacy_policy.html")

def terms_of_service(request):
    return render(request, "core/terms_of_service.html")



