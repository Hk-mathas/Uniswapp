from django.db import models
import datetime 
from django.contrib.auth.models import User


# Create your models here.
class Category(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return str(self.name)
    

class Customer(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    phone = models.IntegerField()
    email = models.EmailField(max_length=50)

    def __str__(self):
        return str(self.user)
    

class Product(models.Model):
    product_name = models.CharField(max_length=50)
    cource = models.ForeignKey(Category, on_delete=models.CASCADE, default=1)
    year = models.CharField(max_length=50, null=True)
    old_price = models.DecimalField(default=0, decimal_places=2, max_digits=10)
    new_price = models.DecimalField(default=0, decimal_places=2, max_digits=10)
    description = models.CharField(max_length=500)
    image = models.ImageField(upload_to='uploads/product/')

    def calculate_discount(self):
        if self.old_price and self.new_price:
            discount = ((self.old_price - self.new_price) / self.old_price) * 100
            return discount
        else:
            return None

    def __str__(self):
        return str(self.product_name)
    
class Order(models.Model):
    item = models.ForeignKey(Product, on_delete=models.CASCADE, default=1 )
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, default=1 )
    date = models.DateField(default = datetime.datetime.today)

