// MESSAGE ----------------------------------

setTimeout(function() {
  document.querySelectorAll('.messages .alert').forEach(alert => {
      alert.classList.add("h0")
  });
}, 3000);





// NAVBAR--------------------------------------

drop = document.querySelector(".drop");
loginbtn = document.querySelector('.account');
loginbtn.addEventListener('mouseover', function() {
    drop.classList.toggle("hidden");
});

document.addEventListener('click', function(event) {
    if (!drop.contains(event.target) && event.target !== loginbtn) {
        drop.classList.add("hidden");
    }
});

// hamburger menu
ham = document.querySelector(".hamburger")
links = document.querySelector(".mobile_header")
// show sidebar
ham.addEventListener("click", ()=> {
  links.style.left = "0";
})

// hide sidebar
document.querySelector(".hide").addEventListener("click", ()=> {
  links.style.left = "-80vw";
})



// Swiper -------------------------------------------7

var swiper = new Swiper(".books-list", {

  loop:true,
  centeredSlides:true,
  autoplay:{
    delay:6000,
    disableOnInteraction:false,
  },
  breakpoints: {
    0: {
      slidesPerView:1,
    },
    768: {
      slidesPerView:2,
    },
    1024: {
      slidesPerView:3,
    },
  },
});

// Featured -------------------------------------------

var swiper = new Swiper(".featured-slider", {

  spaceBetween:10,
  loop:true,
  centeredSlides:true,
  autoplay:{
    delay:9500,
    disableOnInteraction:false,
  },
 navigation:{
        nextEl:".swiper-button-next",
        prevEl:".swiper-button-prev",
    },
  breakpoints: {
    0: {
      slidesPerView:1,
    },
    450: {
      slidesPerView:2,
    },
    768: {
      slidesPerView:3,
    },
    1024: {
      slidesPerView:4,
    },
  },
});

// window scroll ----------------------------------------

window.onscroll = () =>{

  searchform.classList.remove('active');

  if (window.scrollY > 0){
    document.querySelector('.header .header_two').classList.add('active');

  }else{
    document.querySelector('.header .header_two').classList.remove('active');
  }
}

window.onload = () => {

  if (window.scrollY > 80){
    document.querySelector('.header .header_two').classList.add('active');

  }else{
    document.querySelector('.header .header_two').classList.remove('active');
  }
}

// arrivals Section -------------------------------------------

  var swiper = new Swiper('.arrivals-slider', {
    spaceBetween:10,
    loop:true,
    centeredSlides:true,
    autoplay:{
      delay:9500,
      disableOnInteraction:false,
    },
    breakpoints: {
      0: {
        slidesPerView:1,
      },
      768: {
        slidesPerView:2,
      },
      1024: {
        slidesPerView:3,
      },
    },
  });

  /*------ review section --------*/

  var swiper = new Swiper(".reviews-slider", {
    spaceBetween:10,
    loop:true,
    centeredSlides:true,
    autoplay:{
      delay:9500,
      disableOnInteraction:false,
    },
    breakpoints: {
      0: {
        slidesPerView:1,
      },
      768: {
        slidesPerView:2,
      },
      1024: {
        slidesPerView:3,
      },
    },
  });

// contact page *******************************************************************************************

const inputs = document.querySelectorAll(".input");

function focusFunc() {
  let parent = this.parentNode;
  parent.classList.add("focus");
}

function blurFunc() {
  let parent = this.parentNode;
  if (this.value == "") {
    parent.classList.remove("focus");
  }
}

inputs.forEach((input) => {
  input.addEventListener("focus", focusFunc);
  input.addEventListener("blur", blurFunc);
});




// smtp email send -------------------------------


function Send(){
          
  var name = document.getElementById("Name").value;
  var email = document.getElementById("Email").value;
  var contact = document.getElementById("Contact").value;
  var sub = document.getElementById("subject").value;
  var mess = document.getElementById("message").value;

  var body = "Name: " + name + "<br/> Email:" + email + "<br/> Contact Number:" + contact + "<br/> Message:" + mess;
   console.log("called");
   Email.send({
    Host : "smtp.elasticemail.com",
    Username : "kanwr420@gmail.com",
    Password : "13632BA35F37D94E47006D940E2FDA54A358",
    To : "uniswap.help@gmail.com",
    From : "kanwr420@gmail.com",
    Subject : sub,
    Body: mess,
   }).then(
       message =>{
           if(message=='OK'){
               swal("Successfull", "Your Data was Successfully Received", "success");
           }
           else{

               swal("Something Wrong", "Your Data was not Received", "error");
           }
       }
     );
}



